<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
1  2  3  4  5  6  7  8  9  10  11  12  13  14  15  16  17  18  19  20  <br />staff1 => سعید<br />staff2 =>  حمید  <br />staff3 =>   پیمان Array
(
    [staff1] => سعید
    [staff2] =>  حمید  
    [staff3] =>   پیمان 
)
<br />array(3) {
  ["staff1"]=>
  string(8) "سعید"
  ["staff2"]=>
  string(11) " حمید  "
  ["staff3"]=>
  string(13) "  پیمان "
}
<br />0 =>   پیمان <br />1 =>  حمید  <br />2 => سعید <br /> <br />staff3 =>   پیمان  <br /> staff2 =>  حمید   <br /> staff1 => سعید <br /> customer =>   پیمان  <br /> manager =>  حمید   <br /> staff => سعید <br /> سرکارگر =>  حمید   <br /> مدیر => سعید <br /> کارگر =>   پیمان  <br /> 1 <br /> 2 <br /> 3 <br /> 4 <br /> 5 <br /> 6 <br /> 7 <br /> 8 <br /> 9 <br /> 10 <br /> 1  2  3  4  5  6  7  8  9  10  1  2  3  4  5  6  7  8  9  10  